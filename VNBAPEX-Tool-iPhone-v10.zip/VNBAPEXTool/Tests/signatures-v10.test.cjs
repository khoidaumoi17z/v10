const assert=require('node:assert/strict'),S=require('../App/Web/signatures.js');
const bytes=Buffer.alloc(256),patterns=S.patterns;bytes.set(Buffer.from(patterns[0],'hex'),0);bytes.set(Buffer.from(patterns[1],'hex'),32);bytes.set(Buffer.from(patterns[2],'hex'),65);bytes.set(Buffer.from(patterns[3],'hex'),128);
const section={va:0x1000n,size:128n,name:'__text',flags:0x80000400};
const model={rows:[{va:0x1000n,name:'sub_1000'}],base:0x1000n,sections:[section,{va:0x1080n,size:128n,name:'__cstring',flags:0}],codeSection:va=>va<0x1080n?section:null,map:va=>({fileOffset:va-0x1000n})};
let result=S.scan(bytes,model);assert.equal(result.stats.total,2);assert.equal(result.stats.atFunctionStart,1);assert.equal(result.stats.insideFunction,1);assert.equal(result.hits[1].fileOffset,32n);assert.equal(result.hits[1].rva,32n);assert.equal(result.hits[1].verifiedRuntime,false);
model.signatureScan=result;assert.equal(S.forRow(model.rows[0],model).length,2);
model.encrypted=true;assert.equal(S.scan(bytes,model).hits.length,0);model.encrypted=false;
for(let i=0;i<patterns.length;i++){bytes.fill(0);bytes.set(Buffer.from(patterns[i],'hex'),0);assert.equal(S.scan(bytes,model).hits[0].pattern,'P'+(i+1));bytes[8]^=1;assert.equal(S.scan(bytes,model).hits.length,0);}
const C=require('../App/Web/core.js'),E=require('../App/Web/evidence.js');require('../App/Web/fingerprints.js');require('../App/Web/machine.js');require('../App/Web/relations.js');require('../App/Web/assessment.js');const F=require('../App/Web/focus.js');
// Prologue alone must never create a shortlisted security candidate.
model.rows[0].calls=[];model.rows[0].evidence=[];model.rows[0].controlFlow={checks:[]};model.callGraph={edges:[],checks:[],references:[],machineCalls:[]};model.stringFindings=[];assert.equal(F.shortlist(F.rank(model.rows,model),{mode:'explore'}).length,0);
console.log('PASS all 9 exact prologues, alignment/code/data bounds, metadata ownership, encryption, mutation negatives and prologue-only ranking.');
