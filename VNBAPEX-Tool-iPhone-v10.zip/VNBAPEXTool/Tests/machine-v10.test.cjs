const assert=require('node:assert/strict');
const C=require('../App/Web/core.js'),E=require('../App/Web/evidence.js');require('../App/Web/fingerprints.js');const M=require('../App/Web/machine.js'),R=require('../App/Web/relations.js');require('../App/Web/assessment.js');const F=require('../App/Web/focus.js');
function fixture(){
 const b=Buffer.alloc(0x600),base=0x100000000n;const u=(p,n)=>b.writeUInt32LE(n>>>0,p),q=(p,n)=>b.writeBigUInt64LE(BigInt(n),p),name=(p,s)=>b.write(s,p,'ascii');u(0,0xfeedfacf);u(4,0x100000c);u(8,0);u(12,6);u(16,4);u(20,432);
 let p=32;u(p,0x19);u(p+4,312);name(p+8,'__TEXT');q(p+24,base);q(p+32,b.length);q(p+40,0);q(p+48,b.length);u(p+60,5);u(p+64,3);
 const sections=[['__text',0x200,0x80,0x80000400,0,0],['__stubs',0x300,24,0x80000408,0,12],['__got',0x340,16,6,2,0]];
 sections.forEach(([n,off,size,flags,res1,res2],i)=>{const x=p+72+i*80;name(x,n);name(x+16,'__TEXT');q(x+32,base+BigInt(off));q(x+40,size);u(x+48,off);u(x+64,flags);u(x+68,res1);u(x+72,res2);});p+=312;
 u(p,2);u(p+4,24);u(p+8,0x400);u(p+12,2);u(p+16,0x440);u(p+20,64);p+=24;
 u(p,0xb);u(p+4,80);u(p+56,0x3d0);u(p+60,4);p+=80;u(p,0x26);u(p+4,16);u(p+8,0x3c0);u(p+12,3);
 b.set([0x80,4,0],0x3c0);[0,1,0,1].forEach((n,i)=>u(0x3d0+4*i,n));u(0x400,1);b[0x404]=1;u(0x410,9);b[0x414]=1;name(0x441,'_sysctl\0_vm_read\0');
 const words=[0x94000040,0xaa0003f3,0xb40000d3,0xd503201f,0x9400003f,0x7100001f,0x54000060,0xd65f03c0,0xd503201f,0xd65f03c0];words.forEach((w,i)=>u(0x200+4*i,w));return b;
}
function scan(b){const m=C.parseMachO(b.buffer.slice(b.byteOffset,b.byteOffset+b.length));m.stringFindings=[];m.callGraph=R.binary(b,m);return m;}
let b=fixture(),m=scan(b);assert.equal(m.importStats.stubEntries,2);assert.equal(m.importStats.pointerEntries,2);assert.equal(m.rows.length,1);assert.equal(m.callGraph.machineCalls.length,2);assert.equal(m.callGraph.checks.length,2);assert(m.callGraph.checks.some(c=>c.method.includes('MOV')));assert.equal(F.shortlist(F.rank(m.rows,m)).length,1);assert.equal(F.rank(m.rows,m)[0].score,56);
assert.equal(m.imports[0].va,0x100000300n);assert.equal(m.imports[0].fileOffset,0x300n);
const fat=Buffer.alloc(0x1000+b.length);fat.writeUInt32BE(0xcafebabe,0);fat.writeUInt32BE(1,4);fat.writeUInt32BE(0x100000c,8);fat.writeUInt32BE(0x1000,16);fat.writeUInt32BE(b.length,20);b.copy(fat,0x1000);const fm=scan(fat);assert.equal(fm.imports[0].fileOffset,0x1300n);assert.equal(F.rank(fm.rows,fm)[0].address.fileOffset,0x1200n);
let bad=fixture();bad.writeUInt32LE(99,32+72+2*80+68);assert.throws(()=>scan(bad),/indirect symbol/);bad=fixture();bad.writeUInt32LE(0,32+72+80+72);assert.throws(()=>scan(bad),/stub\/pointer/);
// Undefined import names alone, and generic compare/log APIs, never make a strong candidate.
b=fixture();b.fill(0,0x200,0x280);m=scan(b);assert.equal(F.shortlist(F.rank(m.rows,m)).length,0);
b=fixture();b.fill(0,0x440,0x480);b.write('_memcmp\0_memcpy\0',0x441);m=scan(b);assert.equal(F.shortlist(F.rank(m.rows,m),{mode:'explore'}).length,0);
function track(words,options={}){const bytes=Buffer.alloc(256);words.forEach((w,i)=>bytes.writeUInt32LE(w>>>0,i*4));const model={rows:[{name:'sub_1000',va:0x1000n,calls:[]}],imports:[{name:'_sysctl',va:0x1100n,kind:'stub'},{name:'_sysctl',va:0x1080n,kind:'pointer'}],sections:[{name:'__text',flags:0x80000400,va:0x1000n,size:BigInt(words.length*4)}],map:va=>va>=0x1000n&&va<0x1100n?{fileOffset:va-0x1000n}:null,codeSection:va=>va>=0x1000n&&va<0x1100n?{name:'__text'}:null,stringFindings:options.strings||[]};if(options.pointer!==undefined)bytes.writeBigUInt64LE(options.pointer,0x80);const machine=M.create(bytes,model);words.forEach((w,i)=>machine.push(w>>>0,0x1000n+BigInt(i*4),0x1000n));return machine.finish();}
assert.equal(track([0x94000040,0xaa0003f3,0xb4000053,0xd65f03c0,0xd65f03c0]).checks.length,1);
assert.equal(track([0x94000040,0xd2800013,0xb4000053,0xd65f03c0,0xd65f03c0]).checks.length,0); // clobber
assert.equal(track([0x94000040,0,0xb4000040,0xd65f03c0]).checks.length,0); // unsupported
assert.equal(track([0x94000040,0x14000002,0xaa0003f3,0xb4000053,0xd65f03c0]).checks.length,0); // jump into MOV chain
assert.equal(track([0x94000040,0x7100001f,...Array(13).fill(0xd503201f),0x54000040,0xd65f03c0]).checks.length,0); // age
// ADRP x16; NOP; LDR x16,[x16,#0x80]; BLR x16; CBZ x0.
const indirect=track([0x90000010,0xd503201f,0xf9404210,0xd63f0200,0xb4000040,0xd65f03c0]);assert.equal(indirect.stats.indirectImportCalls,1);assert.equal(indirect.checks.length,1);
const strings=[{name:'jailbreak',va:0x1080n,fileOffset:0x80n,section:'__cstring',evidence:E.textEvidence('jailbreak','string')}];
assert.equal(track([0x90000001,0xd503201f,0x91020020],{strings}).references.length,1);
assert.equal(track([0x90000001,0xd2800001,0x91020020],{strings}).references.length,0);
assert.equal(track([0x14000002,0x90000001,0x91020020],{strings}).references.length,0); // incoming block target
assert(E.callEvidence('__dyld_image_count').length);assert(E.callEvidence('_mach_vm_region_recurse').length);
console.log('PASS v10 Mach-O indirect imports/FAT bounds, BL/MOV/condition, imported BLR, API-only negatives, clobber/unknown/join/age barriers and non-adjacent XREF.');
