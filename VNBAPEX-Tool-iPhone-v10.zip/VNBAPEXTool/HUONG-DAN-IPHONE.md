# VNBAPEX Tool v10 — mẫu byte và phân tích Mach-O

## Kết quả trên file anogs đã cung cấp

| Chỉ tiêu | v9 | v10 |
|---|---:|---:|
| Mốc hàm metadata | 13.323 | 13.323 |
| Đầu mối từ 35 điểm | 1 | 28 |
| Đầu mối từ 55 điểm | 0 | 2 |
| Lời gọi import được ánh xạ | 0 | 7.117 |
| XREF chuỗi được nhận | 3 | 3 |

Hai đầu mối từ 55 điểm nằm trong 28 đầu mối từ 35 điểm. Đây là tăng độ bao phủ phân tích, chưa đo được độ chính xác vì chưa có nhãn chức năng hoặc kiểm chứng runtime. Không có bằng chứng để gọi 28 hàm này là 28 offset antiban hiệu quả.

9 mẫu byte người dùng khớp 489 vị trí trong section mã: 484 trùng đầu hàm metadata, 5 nằm bên trong khoảng hàm. Có 6 hàm khớp đầu hàm đồng thời đạt ngưỡng 35 bằng các bằng chứng khác. Các mẫu là phần mở đầu ARM64 lưu thanh ghi/cấp stack; chức năng thông thường cũng có thể dùng cùng byte. Điểm cao nhất trong kết quả mẫu này là 56/100, không phải 56% xác suất antiban.

## Cách đọc kết quả

1. Nạp Mach-O ARM64 đã giải mã, ví dụ file anogs. Giữ giới hạn 100 MiB (104.857.600 byte) mỗi tệp.
2. Chọn **Thăm dò — từ 35 điểm**, giới hạn **50** hoặc **100** để xem hết 28 đầu mối trên file mẫu. Chế độ chặt từ 55 chỉ hiển thị 2 đầu mối. Không ép số hàm khi thiếu bằng chứng.
3. Chọn một dòng để xem điểm thành phần, lời gọi import, nơi kết quả trả về được dùng trong nhánh, mẫu byte và nguồn ánh xạ địa chỉ.
4. Mở **Đối chiếu 9 mẫu byte người dùng** để xem tối đa 100 vị trí khớp. **Xuất tất cả vị trí khớp byte** chứa các vị trí đã giữ, VA/RVA/file offset, hàm chứa vị trí và điểm ưu tiên của hàm. Khớp ở bên trong khoảng hàm không được tự coi là đầu hàm.
5. **Xuất hàm ưu tiên + offset** xuất danh sách theo bộ lọc. **Xuất chẩn đoán phân tích** xuất số lượng/giới hạn/cảnh báo, giúp giải thích vì sao một tệp có ít kết quả.

Tool tìm byte chính xác, đúng thứ tự byte người dùng gửi, chỉ tại địa chỉ căn 4 byte trong vùng mã được hỗ trợ. Không thêm wildcard tùy tiện; mẫu bị thay đổi sẽ không khớp. Dump C không có byte máy đáng tin cậy nên chỉ áp dụng điều kiện C/chuỗi/lời gọi; nạp Mach-O cùng bản để đối chiếu byte. Cùng địa chỉ chưa chứng minh dump và binary cùng phiên bản.

## Thuật toán v10

- Đọc LC_DYSYMTAB/indirect symbol table, reserved1/reserved2 của section để ánh xạ tên import vào stub và pointer. Có kiểm tra biên dữ liệu và slice FAT.
- Quét BL, một số BLR qua import pointer, B tail-call tới đích được nhận diện. Nhận tên API dyld, sysctl, đọc/quan sát bộ nhớ với ngữ cảnh lời gọi thực tế.
- Theo dõi nguồn thanh ghi tối đa 12 lệnh/48 byte trong đoạn thẳng: ADR/ADRP, ADD, MOV, một số tải/hằng, giá trị trả về và CMP/CBZ/TBZ/B.cond. Xóa trạng thái khi gặp nhánh, điểm nhập nhánh, thay hàm, ghi đè hoặc lệnh không hỗ trợ. Đây là phân tích cục bộ, chưa có CFG đầy đủ như IDA.
- Mẫu byte chỉ cộng 4 điểm khi trùng đầu hàm metadata và có XREF/điều kiện/lời gọi dùng kết quả trong nhánh. Mẫu đơn lẻ không tạo ứng viên ưu tiên và không đủ xác nhận vai trò bảo mật.
- API quan sát: 6 điểm/tên, tối đa 12; dùng kết quả trong nhánh +24; hội tụ ít nhất 2 nhóm API +8. API chung có thể phục vụ chức năng bình thường, nên điểm bị giới hạn 45 cho một nhóm hoặc 65 cho nhiều nhóm khi thiếu bằng chứng cụ thể. Giữ quy tắc giảm ưu tiên log, hàm tiện ích và vòng đời.
- Giữ các điều kiện C, XREF, tên/chuỗi cụ thể, đối chiếu cấu trúc phiên bản và chỉ truyền ngữ cảnh một bước từ bản trước. Điểm là trọng số ưu tiên đọc, không phải xác suất được hiệu chuẩn.

Không phân giải đầy đủ chained fixups, PAC, dlsym động, Objective-C/CFString, chuỗi mã hóa, luồng qua bộ nhớ hay mọi lệnh ARM64. Các điểm dừng bảo thủ có thể bỏ sót. Tối đa 100.000 quan hệ/import slot, 20.000 XREF/điều kiện/mẫu byte và 200.000 đích nhánh cho theo dõi thanh ghi; báo khi chạm giới hạn. Chưa thể tự xác nhận offset có hiệu quả bỏ qua kiểm tra gian lận. Phải xác định hành vi hàm và đường đi tới quyết định bằng phân tích mã/runtime; nguồn dữ liệu tĩnh không cho biết quyết định ban ở máy chủ.

## Dump C và nhật ký

Giữ bộ nhập theo chunk UTF-8, UTF-16 LE/BE, BOM; nhận nhãn sub_HEX/FUN_HEX và tên đổi trong listing IDA có header địa chỉ. Giữ quét bằng chứng sau phần xem trước bị rút gọn. C# dump.cs, ASM, APK/ELF Android không tự chuyển thành dump C/Mach-O.

Nếu bộ chọn tệp không mở được, chép tệp vào Tệp → Trên iPhone → VNBAPEX Tool rồi chọn **Tệp trong ứng dụng**. Log đã sửa để lấy số phiên bản từ bundle thay vì ghi cố định v6. Log bạn gửi ghi nhận file 2.955.456 byte được nhập thành công; nó không ghi lỗi nhập dump C. Chưa có log lỗi dump C mới để tái hiện đúng lỗi trên máy bạn.

## Đối chiếu bản mới

Nạp bản cũ → **Ghi mốc phiên bản** → nạp bản mới → **Đối chiếu bản đang nạp**. Mốc chỉ giữ trong phiên mở app, tối đa 2.000 hàm có điểm từ 35. Kết quả mơ hồ phải đọc lại; độ tương đồng không chứng minh cùng hành vi hoặc nhà phát triển đã thay một offset cụ thể.

## Tạo IPA bằng GitHub

1. Upload **VNBAPEX-Tool-iPhone-v10.zip** vào gốc repository, giữ nguyên tên ZIP.
2. Tạo hoặc thay file **.github/workflows/build-ipa.yml** bằng nội dung **VNBAPEX-build-ipa-v10.yml** đi kèm. Commit lên nhánh mặc định.
3. Mở **Actions → Build VNBAPEX Tool v10 → Run workflow**.
4. Khi thành công, tải artifact **VNBAPEX-Tool-v10-unsigned-IPA**, giải nén lấy **VNBAPEX-Tool-v10-unsigned.ipa**.
5. Ký IPA bằng chứng chỉ/provisioning phù hợp trước khi cài. Workflow đóng gói bản chưa ký, không yêu cầu secrets ký. Sau khi cài, kiểm tra tiêu đề v10.0.

Workflow chạy 9 bộ kiểm thử Node rồi dùng XcodeGen/xcodebuild trên macOS, kiểm tra tài nguyên machine.js/signatures.js và đóng gói ứng dụng ARM64. Nếu lỗi, xem bước đỏ hoặc artifact build-log; bước lỗi trước build có thể chưa tạo log.

## Kiểm chứng

Đã chạy 9 bộ kiểm thử Node, kiểm tra cú pháp JavaScript, DOM/cầu nối iOS mô phỏng và phân tích file anogs thật. Bao gồm đủ 9 mẫu byte, đối chứng lệch căn/ngoài mã/sửa byte/mã hóa, ánh xạ FAT/import, ghi đè thanh ghi/nhánh nhập/lệnh chưa hỗ trợ, mẫu byte đơn lẻ và ranh giới nhập 100 MiB. Chi tiết trong VALIDATION.json.

Chưa build bằng Xcode hoặc chạy trên iPhone thật trong môi trường này; workflow GitHub là bước kiểm chứng build. Không có phép đo precision/recall hoặc thử nghiệm hiệu quả antiban. Không kèm binary game trong source ZIP.

Có thể tạo báo cáo tổng hợp cục bộ bằng:

```sh
node Tests/analyze-file.cjs /duong-dan/anogs report.json
```

## Tài liệu tham khảo

- Apple Mach-O loader.h: https://github.com/apple-oss-distributions/xnu/blob/main/EXTERNAL_HEADERS/mach-o/loader.h
- Hex-Rays XREF: https://docs.hex-rays.com/9.0/user-guide/decompiler/interactive/cmd_jump_xref
- IDA imports API: https://ida-domain.docs.hex-rays.com/ref/imports/
- GitHub chạy workflow: https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow
- GitHub tải artifact: https://docs.github.com/en/actions/how-tos/manage-workflow-runs/download-workflow-artifacts
