/* Read-only indicators. An occurrence is evidence of text/API usage, never proof of anti-cheat. */
(function(root){
'use strict';
const MAX_FILE_BYTES=100*1024*1024;
const terms=[
 ['hook','Kiểm tra can thiệp',/\b(?:(?:detect|check)[ _-]?hook|hook[ _-]?(?:detect(?:ion)?|check)|inline[ _-]?hook|code[ _-]?patch|memory[ _-]?scan)\b/i],
 ['signature','Chữ ký / chứng thực',/\b(?:signature[ _-]?(?:verify|verification|check)|(?:verify|check)[ _-]?(?:code[ _-]?)?signature|certificate[ _-]?pinning|attestation)\b/i],
 ['sdk','Tên SDK/bảo mật',/\b(?:AnoSDK\w*|AntiCheatExpert|anti[_ -]?cheat|anti[_ -]?tamper)\b/i],
 ['integrity','Tính toàn vẹn',/\b(?:integrity|checksum|tamper(?:ed|ing)?|code[_ -]?signature)\b/i],
 ['environment','Môi trường thiết bị',/\b(?:(?:is[_ -]?)?jailbreak|jailbroken|root[_ -]?detect(?:ion)?|(?:detect|check)[_ -]?root|emulator[_ -]?detect(?:ion)?|(?:detect|check)[_ -]?emulator)\b/i],
 ['debug','Kiểm tra debugger',/\b(?:anti[_ -]?debug|debugger[_ -]?detect(?:ion)?|debugger[_ -]?attached|(?:is|check|detect)[_ -]?debugger(?:[_ -]?(?:present|attached))?)\b/i],
 ['report','Báo cáo bảo mật',/\b(?:cheat[_ -]?report|report[_ -]?cheat|security[_ -]?report|hack[_ -]?report)\b/i]
];
const apis=[
 ['integrity','Hàm băm (API chung)',/^(?:_?CC_(?:SHA\d+|MD5)(?:_Init|_Update|_Final)?|_?memcmp|_?(?:SHA(?:1|224|256|384|512)|MD5)(?:_Init|_Update|_Final)?)$/],
 ['environment','Liệt kê thư viện (API chung)',/^_?dyld_image_count$|^_?dyld_get_image_name$|^_dyld_image_count$|^_dyld_get_image_name$/],
 ['debug','Thông tin tiến trình/debug (API chung)',/^_?(?:ptrace|sysctl|sysctlbyname)$/],
 ['debug','Kiểm tra debugger (API chung)',/^_?(?:IsDebuggerPresent|CheckRemoteDebuggerPresent)$/],
 ['memory','Đọc bộ nhớ (API chung)',/^_?(?:mach_vm_read|mach_vm_read_overwrite|vm_read|mach_vm_region|mach_vm_region_recurse|vm_region|vm_region_64|task_info)$/],
 ['environment','Tra cứu thư viện (API chung)',/^_?(?:dladdr|dlopen|dlsym)$/]
];
function textEvidence(text,where){const raw=String(text),normalized=raw.replace(/_/g,' ').replace(/([a-z0-9])([A-Z])/g,'$1 $2');return terms.filter(t=>t[2].test(raw)||t[2].test(normalized)).map(t=>({group:t[0],category:t[1],kind:'keyword',where,excerpt:String(text).slice(0,200)}));}
function callEvidence(name){name=String(name).replace(/^_+/,'');return apis.filter(t=>t[2].test(name)).map(t=>({group:t[0],category:t[1],kind:'generic-api',where:'Lời gọi trong dump C',excerpt:name}));}
function unique(evidence){const seen=new Set();return evidence.filter(e=>{const k=e.group+'|'+e.kind+'|'+e.excerpt;if(seen.has(k))return false;seen.add(k);return true;}).slice(0,24);}
function forRow(row){return unique([...textEvidence(row.name.replace(/^_+/,''),'Tên hàm/symbol'),...(row.evidence||[]),...(row.calls||[]).flatMap(callEvidence)]);}
function certainty(evidence){return evidence.some(e=>e.kind==='keyword')?'Dấu hiệu từ tên/chuỗi; chưa xác minh':'API dùng chung; bằng chứng yếu';}
function stringScanner(){
 const ascii={start:0,run:0,head:''},wide=[{start:0,run:0,head:''},{start:0,run:0,head:''}];let previous=null,previousOffset=0,hits=[],total=0;
 function flush(state,encoding,width){if(state.run>=5&&state.run<=4096){const evidence=unique([...textEvidence(state.head,'Chuỗi '+encoding+' trong binary'),...callEvidence(state.head).map(e=>({...e,where:'Tên API dạng chuỗi '+encoding+'; chưa chứng minh có lời gọi'}))]);if(evidence.length){total++;if(hits.length<4000)hits.push({fileOffset:BigInt(state.start),byteLength:state.run*width,text:state.head.slice(0,200),encoding,evidence});}}state.run=0;state.head='';}
 function add(state,value,offset){if(!state.run)state.start=offset;state.run++;if(state.head.length<4096)state.head+=String.fromCharCode(value);}
 function reset(state){state.run=0;state.head='';}
 return {push(bytes,offset){for(let i=0;i<bytes.length;i++){const b=bytes[i],at=offset+i;
  if(b>=32&&b<=126)add(ascii,b,at);else if(b===0)flush(ascii,'ASCII',1);else reset(ascii);
  if(previous!==null&&previousOffset+1===at){const state=wide[previousOffset%2];if(previous>=32&&previous<=126&&b===0)add(state,previous,previousOffset);else if(previous===0&&b===0)flush(state,'UTF-16LE (Basic Latin)',2);else reset(state);}
  previous=b;previousOffset=at;
 }},finish(){return {hits,total,truncated:total>hits.length,limit:4000};}};
}
function mapString(hit,model){const off=hit.fileOffset-BigInt(model.slice),end=off+BigInt(hit.byteLength);
 const section=model.sections.find(s=>![1,12,18].includes(s.flags&255)&&off>=BigInt(s.off)&&end<=BigInt(s.off)+s.size);
 const segment=model.segments.find(s=>off>=s.off&&end<=s.off+s.size);
 const va=segment?segment.va+off-segment.off:null;
 return {...hit,kind:'string',name:hit.text,va,rva:va===null?null:va-model.base,sliceOffset:off,section:section?section.segment+','+section.name:'ngoài section đã biết',certainty:certainty(hit.evidence),addressNote:'Địa chỉ chuỗi dữ liệu, KHÔNG phải địa chỉ hàm tham chiếu.'};
}
function decodeCLiteral(raw){
 return String(raw).replace(/\\\r?\n/g,'').replace(/\\(?:x([0-9a-fA-F]+)|u([0-9a-fA-F]{4})|U([0-9a-fA-F]{8})|([0-7]{1,3})|([\s\S]))/g,(whole,hex,u,U,oct,c)=>{
  if(hex||oct){const n=parseInt(hex||oct,hex?16:8);return n<=255?String.fromCharCode(n):whole;}
  if(u||U){const n=parseInt(u||U,16);return n<=0x10ffff&&!(n>=0xd800&&n<=0xdfff)?String.fromCodePoint(n):whole;}
  const known={n:'\n',r:'\r',t:'\t',b:'\b',f:'\f',v:'\v',a:'\x07','\\':'\\','"':'"',"'":"'",'?':'?'};return Object.prototype.hasOwnProperty.call(known,c)?known[c]:whole;
 });
}
const api={decodeCLiteral,MAX_FILE_BYTES,textEvidence,callEvidence,unique,forRow,certainty,stringScanner,mapString};root.OffsetEvidence=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis==='undefined'?this:globalThis);
