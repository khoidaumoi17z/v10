/* Static references only. BL sites are decoded from bytes; caller boundaries are metadata intervals. */
(function(root){
'use strict';
const LIMIT=100000;
function binary(bytes,model){
 const edges=[],references=[],checks=[],stringTargets=new Map((model.stringFindings||[]).filter(f=>f.va!==null&&f.section!=='ngoài section đã biết').map(f=>[f.va.toString(),f])),stats={scannedInstructions:0,directBL:0,resolvedBL:0,stored:0,truncated:false,skipped:model.encrypted?'Vùng mã còn mã hóa':''};
 for(const row of model.rows)delete row.binaryFingerprint;
 if(model.encrypted){model.signatureScan=root.OffsetSignatures?.scan(bytes,model)||null;return {edges,references,checks,stats};}
 model.signatureScan=root.OffsetSignatures?.scan(bytes,model)||null;
 const machine=root.OffsetMachine?.create(bytes,model);
 const targets=new Map(model.rows.map(r=>[r.va.toString(),r]));
 for(const section of model.sections){
  if(!(section.name==='__text'||(section.flags&0x80000400)!==0)||['__stubs','__auth_stubs','__stub_helper'].includes(section.name)||section.va%4n||!section.size)continue;
  const range=model.map(section.va),end=model.map(section.va+section.size-1n);
  if(!range||!end||end.fileOffset!==range.fileOffset+section.size-1n)continue;
  const offset=Number(range.fileOffset),size=Number(section.size);if(offset<0||offset+size>bytes.length)continue;
  const functions=model.rows.filter(r=>r.va>=section.va&&r.va<section.va+section.size).map(r=>({va:r.va,relative:Number(r.va-section.va),row:r}));let cursor=-1,shape=null;
  function flushShape(){if(shape&&cursor>=0)functions[cursor].row.binaryFingerprint=shape.finish();}
  for(let p=0;p+4<=size;p+=4){
   stats.scannedInstructions++;while(cursor+1<functions.length&&functions[cursor+1].relative<=p){flushShape();cursor++;shape=root.OffsetFingerprint?.sketch('arm64-word4')||null;}
   const q=offset+p,w=(bytes[q]|bytes[q+1]<<8|bytes[q+2]<<16|bytes[q+3]<<24)>>>0;
   shape?.push(root.OffsetFingerprint.armWord(w));machine?.push(w,section.va+BigInt(p),cursor>=0?functions[cursor].va:null);
   // Only ADR or an adjacent ADRP + 64-bit ADD immediate constructing an exact stored string address.
   if(!machine&&((w>>>0)&0x1f000000)===0x10000000&&(w&31)!==31){
    let imm=(((w>>>5)&0x7ffff)*4)+((w>>>29)&3);if(imm&0x100000)imm-=0x200000;
    const siteVA=section.va+BigInt(p);let address=null,method='ADR',endSite=siteVA;
    if((w>>>31)===0)address=siteVA+BigInt(imm);
    else if(p+8<=size){const a=(bytes[q+4]|bytes[q+5]<<8|bytes[q+6]<<16|bytes[q+7]<<24)>>>0;
     if(((a&0xff800000)>>>0)===0x91000000&&((a>>>5)&31)===(w&31)&&(a&31)!==31){address=(siteVA&~4095n)+BigInt(imm)*4096n+BigInt((a>>>10)&4095)*((a>>>22)&1?4096n:1n);method='ADRP + ADD kề nhau';endSite=siteVA+4n;}
    }
    const string=address===null?null:stringTargets.get(address.toString());
    if(string&&references.length<20000)references.push({callerVA:cursor>=0?functions[cursor].va:null,siteVA,endSite,stringVA:address,stringFileOffset:string.fileOffset,text:string.name,evidence:string.evidence,method,note:'Mẫu dựng đúng địa chỉ chuỗi; chưa chứng minh dữ liệu đi vào điều kiện bảo mật. Hàm chứa lệnh suy theo khoảng metadata.'});
    else if(string)stats.referencesTruncated=true;
   }
   if(w>>>26!==0x25)continue;stats.directBL++;
   let imm=w&0x03ffffff;if(imm&0x02000000)imm-=0x04000000;
   const siteVA=section.va+BigInt(p),targetVA=siteVA+BigInt(imm*4);if(!targets.has(targetVA.toString()))continue;stats.resolvedBL++;
   if(edges.length>=LIMIT){stats.truncated=true;continue;}
   edges.push({callerVA:cursor>=0?functions[cursor].va:null,siteVA,targetVA,source:'ARM64 BL',note:'Điểm gọi giải mã trực tiếp; hàm chứa điểm gọi suy theo khoảng giữa các mốc metadata, chưa xác minh ranh giới.'});
   // Exact adjacent return-register condition patterns; do not infer distant def-use.
   const boundary=cursor+1<functions.length?functions[cursor+1].relative:size;
   const word=at=>(bytes[offset+at]|bytes[offset+at+1]<<8|bytes[offset+at+2]<<16|bytes[offset+at+3]<<24)>>>0;
   if(!machine&&cursor>=0&&p+8<=boundary&&checks.length<20000){
    const next=word(p+4);let conditionSiteVA=null,branchTargetVA=null,method='';
    if(((next&0x7e00001f)>>>0)===0x34000000||((next&0x7e00001f)>>>0)===0x36000000){
     const bitTest=((next&0x7e00001f)>>>0)===0x36000000;
     let displacement=bitTest?(next>>>5)&0x3fff:(next>>>5)&0x7ffff;
     if(displacement&(bitTest?0x2000:0x40000))displacement-=bitTest?0x4000:0x80000;
     conditionSiteVA=siteVA+4n;branchTargetVA=conditionSiteVA+BigInt(displacement*4);method=bitTest?'BL + TBZ/TBNZ W0/X0':'BL + CBZ/CBNZ W0/X0';
    }else if(((next&0x7fffffff)>>>0)===0x7100001f&&p+12<=boundary){
     const branch=word(p+8);
     if(((branch&0xff000010)>>>0)===0x54000000&&(branch&15)<14){let displacement=(branch>>>5)&0x7ffff;if(displacement&0x40000)displacement-=0x80000;conditionSiteVA=siteVA+8n;branchTargetVA=conditionSiteVA+BigInt(displacement*4);method='BL + CMP W0/X0,#0 + B.cond';}
    }
    if(conditionSiteVA!==null&&branchTargetVA>=section.va&&branchTargetVA<section.va+section.size)checks.push({callerVA:functions[cursor].va,siteVA,targetVA,targetName:targets.get(targetVA.toString()).name,conditionSiteVA,branchTargetVA,method,note:'Mẫu liền kề dùng thanh ghi trả về trong nhánh; ranh giới hàm suy từ metadata, chưa phải CFG đầy đủ.'});
   }

  }
  flushShape();
 }
 let machineCalls=[],machineStats=null;
 if(machine){const extra=machine.finish(),refKeys=new Set(references.map(r=>r.callerVA+':'+r.siteVA+':'+r.stringVA)),checkKeys=new Set(checks.map(c=>c.siteVA+':'+c.conditionSiteVA));
  for(const r of extra.references){const key=r.callerVA+':'+r.siteVA+':'+r.stringVA;if(refKeys.has(key))continue;refKeys.add(key);if(references.length<20000)references.push(r);else stats.referencesTruncated=true;}
  for(const c of extra.checks){const key=c.siteVA+':'+c.conditionSiteVA;if(checkKeys.has(key))continue;checkKeys.add(key);if(checks.length<20000)checks.push(c);else stats.returnConditionLimitReached=true;}
  for(const e of extra.tails){if(edges.length<LIMIT)edges.push(e);else stats.truncated=true;}
  machineCalls=extra.calls;machineStats=extra.stats;
 }
 stats.stored=edges.length;stats.stringReferences=references.length;stats.returnConditionPatterns=checks.length;stats.returnConditionLimitReached=stats.returnConditionLimitReached||checks.length>=20000;stats.machine=machineStats;return {edges,references,checks,machineCalls,stats};
}
function combine(rows,model){
 const edges=[...(model?.callGraph?.edges||[])],names=new Map(),seen=new Set();let truncated=!!model?.callGraph?.stats?.truncated;let byVA;
 for(const row of rows){for(const n of [row.name,'sub_'+row.va.toString(16).toUpperCase(),'FUN_'+row.va.toString(16)]){if(!names.has(n))names.set(n,row);else if(names.get(n)?.va!==row.va)names.set(n,null);}}
 for(const row of rows)for(const name of row.calls||[]){let target=names.get(name);
  if(!target){const m=/^(?:sub_|FUN_)([0-9a-f]+)$/i.exec(name);if(m)target=rowsByVA().get(BigInt('0x'+m[1]).toString());}
  if(!target)continue;const key=row.va+'>'+target.va;if(seen.has(key))continue;seen.add(key);
  if(edges.length>=LIMIT){truncated=true;continue;}
  edges.push({callerVA:row.va,targetVA:target.va,siteVA:null,source:'Dump C',note:'Quan hệ tên lời gọi trong dump C; địa chỉ nhãn và phiên bản chưa xác minh.'});
 }
 function rowsByVA(){return byVA||(byVA=new Map(rows.map(r=>[r.va.toString(),r])));}
 return {edges,truncated};
}
function related(rows,model,seeds,options={}){
 const depth=Math.max(1,Math.min(3,Number(options.depth)||1)),direction=options.direction||'both',maxDegree=Math.max(0,Number(options.maxDegree)||0),graph=combine(rows,model),byVA=new Map(rows.map((r,i)=>[r.va.toString(),{row:r,index:i}])),adj=new Map(),degree=new Map(),found=new Map(),distance=new Map(),queue=[],skippedHubs=new Set();let limited=false;
 function connect(from,to,edge,direction){if(from===null)return;const key=from.toString();if(!adj.has(key))adj.set(key,[]);adj.get(key).push({va:to,edge,direction});}
 const degrees=new Map();for(const e of graph.edges){if(e.callerVA===null)continue;for(const [from,to] of [[e.callerVA,e.targetVA],[e.targetVA,e.callerVA]]){const key=from.toString();if(!degrees.has(key))degrees.set(key,new Set());degrees.get(key).add(to.toString());}
  if(direction==='both'||direction==='outgoing')connect(e.callerVA,e.targetVA,e,'Được hàm trước gọi');if(direction==='both'||direction==='incoming')connect(e.targetVA,e.callerVA,e,'Gọi hàm trước');
 }
 for(const [key,set] of degrees)degree.set(key,set.size);
 for(const key of seeds){if(byVA.has(key)){distance.set(key,0);queue.push({va:BigInt(key),root:BigInt(key),steps:[],depth:0});}}
 for(let q=0;q<queue.length;q++){const current=queue[q],key=current.va.toString();if(current.depth>=depth)continue;if(current.depth>0&&maxDegree&&degree.get(key)>maxDegree){skippedHubs.add(key);continue;}
  for(const link of adj.get(key)||[]){if(link.va===null||!byVA.has(link.va.toString())||seeds.has(link.va.toString()))continue;const to=link.va.toString(),nextDepth=current.depth+1,previous=distance.get(to);if(previous!==undefined&&previous<nextDepth)continue;
   if(!found.has(to)){if(found.size>=5000){limited=true;continue;}found.set(to,{...byVA.get(to),relations:[],hop:nextDepth,degree:degree.get(to)||0});}
   const steps=[...current.steps,{fromVA:current.va,toVA:link.va,callerVA:link.edge.callerVA,targetVA:link.edge.targetVA,siteVA:link.edge.siteVA,source:link.edge.source,note:link.edge.note}];const item=found.get(to);
   if(item.relations.length<16)item.relations.push({anchorVA:current.root,direction:nextDepth===1?link.direction:'Liên kết '+nextDepth+' bước',siteVA:link.edge.siteVA,source:link.edge.source,note:link.edge.note,hop:nextDepth,steps});
   if(previous===undefined){distance.set(to,nextDepth);queue.push({va:link.va,root:current.root,steps,depth:nextDepth});}
  }
 }
 return {items:[...found.values()],stats:{edges:graph.edges.length,truncated:graph.truncated,relatedLimitReached:limited,depth,direction,maxDegree,skippedHubs:skippedHubs.size},degree};
}
const api={binary,combine,related};root.OffsetRelations=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis==='undefined'?this:globalThis);
